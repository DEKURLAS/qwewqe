Bu Site **Ceixsa** Tarafından Yapılmıştır.**Çalan Kişilere** Gerekli İşlemler Yapılacaktır.

Discord : **https://discord.gg/frkZq8XCpH**

Youtube : **https://www.youtube.com/channel/UC9QjCEfyqvVrArzQ7DpwSPQ**